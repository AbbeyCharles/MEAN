var express = require('express');
var app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));

var path = require('path');

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/basic_mongoose');
var MessageSchema = new mongoose.Schema({
  name: String,
  message: String,
  comment: Array
});
mongoose.model('Message', MessageSchema);
var Message = mongoose.model('Message');

// var CommentSchema = new mongoose.Schema({
//   name: String,
//   comment: String
// });
// mongoose.model('Comment', CommentSchema);
// var Comment = mongoose.model('Comment');

mongoose.Promise = global.Promise;

app.use(express.static(path.join(__dirname, './static')));

app.set('views', path.join(__dirname, './views'));

app.set('view engine', 'ejs');

app.get('/', function(req, res){
  Message.find({}, function(err, messages){
    console.log(messages);
    if(err){
      console.log("This is an error from the index.get message route:", err);
    }
    res.render('index', {messages: messages});
  });
});

app.post('/message', function(req, res){
  console.log("POST DATA", req.body);
  var message = new Message({name: req.body.name, message: req.body.message});
  console.log(message);
  message.save(function(err){
    if(err){console.log("This is the error from the message.post route:", err)}
  })
  res.redirect('/');
})

app.post('/comment', function(req, res){
  // var comment = new Comment({comname: req.body.comname, comment: req.body.comment});
  // console.log(comment);
  // comment.save(function(err){
  //   if(err){console.log("This is an error from the comment.post route:", err)};
  // })
  console.log(req.body)
  Message.findOne({_id: req.body.id}, function(err, message){
    console.log(message)
    // if(comment = null){comment = []};
    message.comment.push({name: req.body.comname, comment: req.body.comment});
    // comment.save = comment.save || [];
    message.save(function(err){
      console.log("This is an error in the comment.post route:", err);  ///a
    res.redirect('/');
    });
    ///b
  });
  ///c
})


app.listen(8000, function(){
  console.log('listening on port 8000');
});
