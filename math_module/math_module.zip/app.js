var mathlib = require('./mathlib')();
mathlib.add(2,3);
mathlib.multiply(2,3);
mathlib.square(9);
mathlib.random();
